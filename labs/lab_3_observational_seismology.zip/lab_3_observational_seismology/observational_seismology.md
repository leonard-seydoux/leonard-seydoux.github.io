---
title: "Lab 3: Observational seismology"
date: "\today"  
---

# Lab 3: Observational seismology

<img src="../../../shared/handout/LogoIPGPUPC.png" alt="IPGP Logo" width="180"/> 

<br>

> This lab is part of the Master 2 course _Scientific Computing for Geophysical Problems_ at the [Institut de Physique du Globe de Paris (IPGP)](http://www.ipgp.fr).



## Context

This lab focuses on the spectral analysis of seismic signals. You will learn how to compute and interpret the Fourier transform, and time-frequency analysis of seismic data, identify dominant frequencies, and understand how they relate to various wave propagation modes. The lab will also cover practical applications such as filtering in seismic data processing. You will work in the Jupyter notebook `observational_seismology.ipynb` (see the setup instructions on page 2).

## Scientific objectives

Understand the principle of Fourier transform and its application to seismic signals. Learn the fundamentals of time-frequency analysis including uncertainty principle that trades-off time and frequency resolution. Understand what type of waves are visible in the time domain on three-component seismograms; observe their frequency content in the frequency domain; and identify their propagation modes (body waves, surface waves). Understand the waveform shapes depending on the source type (strike-slip, explosion, etc.) and the source-receiver distance. Filter to observe the dynamic of specific wave types in the time domain. 

## Technical objectives

We will primarily use the `obspy` library to download, read, process, and visualize seismic data. At the beginning of the lab, the instructor will provide a brief introduction to `obspy`, seismic data formats, and the principal seismic data centers. The computation of the Fourier transform will be performed using `numpy` and `scipy` libraries. We will also use `matplotlib` for plotting and visualizing the results. At several steps of the lab, you will be asked to infer the best parameters to use for the analysis (e.g., window length, filter type, etc.).

## Expected outcomes

Overall, the goal is to identify an event of interest (earthquake, explosion, etc.) and analyze its seismic signal in both time and frequency domains to infer basic properties of the source and the wave propagation. For instance, identify the $P$ and $S$ wave arrivals, their frequency content, and how they relate to the source mechanism and distance. You will also be asked to filter the data to enhance specific wave types and observe them in the time domain.

## Data

The data used in this lab will be downloaded from a data center such as IPGP or EarthScope (formerly IRIS). The instructor will provide the necessary information to access and download the data. You will work with three-component seismograms __of your choice__ in standard formats such as MiniSEED.

\newpage

\begin{center}{\bfseries \Large Setup instructions}\end{center}

__Step 1: Connect to stella__

1. Open a terminal on your local machine.
2. Log on to the stella head node: `ssh -XC myusername@stella` (use the password you defined for Lab 1).

__Step 2: Create working directory on stella and copy lab material (first session only)__

1. Navigate to the main directory you created for Lab 1, then create and enter a subdirectory for this lab:

```default
cd ScientificComputing
mkdir Lab3_ObservationalSeismology
cd Lab3_ObservationalSeismology
```

2. Copy all necessary files:

```default
cp -r /gpfs/users/themaster/scientific-computing-for-geophysical-problems/\
Lab3_ObservationalSeismology/* .
```

__In a later session, do not repeat the `cp` command__: it would replace your notebook with the empty one. Simply go back to your directory and resume.

__Step 3: Access jupyter hub__

1. Open Firefox on your local machine and navigate to: [https://dante-jh/jupyter](https://dante-jh/jupyter)
2. Log in using your S-CAPAD/DANTE credentials (login + password).

__Step 4: Configure environment__

1. Select __Advanced Server Options__ and set job duration to __4:00:00__ (4 hours) and the memory to __4 GB__ (instead of the default 2 GB). Make sure that the selected partition is the __jhcpu__ partition.
2. If the __Custom__ environment you created for Lab 1 still appears, select it and click the orange __Start__ button. Otherwise, configure it again: choose __Custom__, Environment Name: `ScientificComputing`, path to jupyter env bin (__noting that there is no space in the path below__):

```default
/gpfs/users/themaster/.conda/envs/scientific_computing/bin
```

then click __Add custom environment__, and the orange __Start__ button.

__Step 5: Open the notebook__

1. Wait for server startup. Use the navigation bar to reach the `Lab3_ObservationalSeismology` directory, inside `ScientificComputing`.
2. Double-click `observational_seismology.ipynb` to start the notebook.
