# Basic signal processing with Python and an application to geomagnetic data

<img width=150px src="https://upload.wikimedia.org/wikipedia/fr/1/16/Institut_de_physique_du_globe_de_paris_logo.svg" />

Made by Alexandre Fournier (fournier@ipgp.fr), modified by Léonard Seydoux (seydoux@ipgp.fr) in 2023 for the course _Scientific Computing for Geophysical Problems_ at the [Institut de physique du globe de Paris](https://www.ipgp.fr).

## Goals

This Jupyter Notebook provides examples of basic signal processing with Python. It covers topics such as generating synthetic time series, computing Fourier transforms, and applying filters to signals. The examples use the `numpy`, `scipy`, `matplotlib`, and `pandas` libraries. Code cells share the notebook kernel, so imports and variables persist between cells; run cells in order unless a cell's prerequisites are already defined.

## Material

The notebook [lab_1_signal_processing.ipynb](lab_1_signal_processing.ipynb) presents the concepts and examples with exercises to complete. If you cannot use Jupyter, the scripts [script_1a_synthetic_data.py](script_1a_synthetic_data.py) (section 2) and [script_1b_geomagnetic_data.py](script_1b_geomagnetic_data.py) (section 3) contain the same exercises. The proposed solutions are provided in [lab_1_signal_processing_solution.ipynb](lab_1_signal_processing_solution.ipynb), [script_1a_synthetic_data_solution.py](script_1a_synthetic_data_solution.py), and [script_1b_geomagnetic_data_solution.py](script_1b_geomagnetic_data_solution.py). The scripts save the figures as PNG and PDF files in a `figures` folder. The notebooks use two datasets located in the `data` folder:

- [`data/chambon_la_foret.dat`](data/chambon_la_foret.dat), which contains 88 years of geomagnetic measurements at Chambon-la-Forêt, France.
- [`data/sunspot_number.dat`](data/sunspot_number.dat), which contains the monthly sunspot number from 1749 to 2025.

## Installation

The Python packages needed for this lab are listed in [pyproject.toml](pyproject.toml), and their exact versions are pinned in [uv.lock](uv.lock). We install them with [uv](https://docs.astral.sh/uv/), a fast Python package and project manager.

1. Install uv by following the [installation guide](https://docs.astral.sh/uv/getting-started/installation/). On macOS and Linux:

   ```bash
   curl -LsSf https://astral.sh/uv/install.sh | sh
   ```

   On Windows:

   ```powershell
   powershell -ExecutionPolicy ByPass -c "irm https://astral.sh/uv/install.ps1 | iex"
   ```

2. Unzip the archive `lab_1_signal_processing.zip` and move to the extracted folder:

   ```bash
   unzip lab_1_signal_processing.zip
   cd lab_1_signal_processing
   ```

3. Create the virtual environment and install the packages. This creates a `.venv` folder in the lab folder, and downloads a suitable version of Python if needed:

   ```bash
   uv sync
   ```

4. Open the notebook with Jupyter:

   ```bash
   uv run jupyter lab lab_1_signal_processing.ipynb
   ```

   Or run the scripts:

   ```bash
   uv run python script_1a_synthetic_data.py
   uv run python script_1b_geomagnetic_data.py
   ```

The `uv run` command runs the given command in the virtual environment of the lab, so there is no need to activate it. In VS Code, select the Python interpreter of the `.venv` folder as the notebook kernel.
