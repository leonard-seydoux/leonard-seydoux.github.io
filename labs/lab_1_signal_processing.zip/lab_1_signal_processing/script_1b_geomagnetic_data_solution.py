"""Basic signal processing with Python: geomagnetic data (section 3).

Proposed solution of script_1b_geomagnetic_data.py (section 3). The code and
the answers are the same as in the notebook
lab_1_signal_processing_solution.ipynb. Run with:

    python script_1b_geomagnetic_data_solution.py

Figures are saved as PNG and PDF files in the figures folder instead of being
shown interactively.
"""

import os

import matplotlib.dates as mdates
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
from scipy import signal

# Folder where the figures are saved
FIGURE_FOLDER = "figures"
os.makedirs(FIGURE_FOLDER, exist_ok=True)


def save_figure(fig, name):
    """Save a figure as PNG and PDF in the figure folder, and close it."""
    fig.savefig(os.path.join(FIGURE_FOLDER, f"{name}.png"))
    fig.savefig(os.path.join(FIGURE_FOLDER, f"{name}.pdf"))
    plt.close(fig)


# 3.1. Loading the data

# Load the monthly means (the header of the file spans 9 lines)
clf = pd.read_fwf("data/chambon_la_foret.dat", skiprows=9)

# Build a datetime index from the date and time columns
clf.index = pd.to_datetime(clf["date"] + " " + clf["time"])
clf.index.name = "datetime"
clf = clf.drop(columns=["date", "time", "doy"])

# Name the columns after the geomagnetic elements: horizontal intensity H
# (nT), declination D (minutes of arc), vertical component Z (nT), and total
# intensity F (nT)
clf = clf.rename(columns={"clfh": "H", "clfd": "D", "clfz": "Z", "clff": "F"})

# The value 88888 flags missing values (F is missing before 1981)
clf = clf.replace(88888.0, np.nan)

# Monthly samples; six months are missing (January 2017 to 2021, and February
# 2021), but we neglect these gaps and treat the samples as evenly spaced
time_step = 1 / 12

# Plot the vertical component of the magnetic field
ax = clf["Z"].plot(grid=True)
ax.set_xlabel("Time $t$ in years")
ax.set_ylabel("$Z(t)$ in nT at Chambon-la-Forêt")
save_figure(ax.get_figure(), "vertical_component")

# The "fast" fluctuations of Z are to some extent concealed by a long-term
# trend.
#
# Question 5: remove the linear trend of Z(t) with `signal.detrend`, store the
# result in `Z_detrended`, and plot it as a function of time. Describe the
# variations that become visible once the trend is removed.

# Remove the linear trend of Z
Z_detrended = signal.detrend(clf["Z"])

# Plot
fig, ax = plt.subplots()
ax.plot(clf.index, Z_detrended)
ax.set_xlabel("Time $t$ in years")
ax.set_ylabel("Detrended $Z(t)$ in nT")
ax.set_title("Vertical component at Chambon-la-Forêt")
ax.grid()
save_figure(fig, "detrended_vertical_component")

# Answer 5: The long-term variation of Z is far from linear: the detrended
# signal still varies by about 350 nT, with a maximum around 1950, a minimum
# between 1985 and 1995, and a steep increase since 2000. These slow variations
# of the main field generated in the Earth's core are called the secular
# variation. On top of them, we now see variations of a few tens of nT from one
# year to the next, and a sudden drop of about 70 nT around 1957, which may be
# of instrumental origin.

# 3.2. Spectral analysis

# Question 6: analyze the spectrum of the northward component X(t) of the
# magnetic field at CLF.
#
# 1. Compute X = H cos(D), as given in the header of the file
#    data/chambon_la_foret.dat. The declination D is given in minutes of
#    arc: convert it to radians before taking the cosine. Store the result in
#    a new column `clf["X"]`.
# 2. Remove the linear trend of X(t) with `signal.detrend` and store the
#    result in `X_detrended`.
# 3. Compute the one-sided power spectral density P_XX(f) of `X_detrended`,
#    as defined in section 2.3 of the notebook.
# 4. Plot X(t) in the left panel, and P_XX(f) as a function of the period in
#    the right panel, with logarithmic axes.
# 5. Find the period of the highest peak of P_XX(f) within each of the
#    following period ranges: 0.4 to 0.6 years, 0.8 to 1.2 years, and 9 to
#    13 years. Which natural phenomenon causes each of these three peaks?


def one_sided_psd(values, time_step):
    """One-sided periodogram estimate of the power spectral density."""
    n_samples = len(values)
    psd = time_step / n_samples * np.abs(np.fft.rfft(values)) ** 2
    psd[1:] *= 2  # add the power of the negative frequencies...
    if n_samples % 2 == 0:
        psd[-1] /= 2  # ...which the Nyquist frequency does not have
    return psd


# Monthly samples (we neglect the few missing months, see section 3.1)
time_step = 1 / 12

# 1. Northward component X = H cos(D), with D converted to radians
clf["X"] = clf["H"] * np.cos(np.deg2rad(clf["D"] / 60))

# 2. Remove the linear trend
X_detrended = signal.detrend(clf["X"])

# 3. One-sided power spectral density
psd = one_sided_psd(X_detrended, time_step)
frequencies = np.fft.rfftfreq(len(X_detrended), d=time_step)
frequencies[0] = np.nan  # the zero frequency has no finite period
periods = 1 / frequencies

# 4. Plot the signal and its power spectral density side by side
fig, (ax_time, ax_spectrum) = plt.subplots(ncols=2, figsize=(8, 3))

ax_time.plot(clf.index, clf["X"])
ax_time.set_xlabel("Time $t$ in years")
ax_time.set_ylabel("$X(t)$ in nT")
ax_time.set_title("Northward component")
ax_time.xaxis.set_major_locator(mdates.YearLocator(20))
ax_time.grid()

ax_spectrum.loglog(periods, psd)
ax_spectrum.set_xlabel("Period $T$ in years")
ax_spectrum.set_ylabel("PSD $P_{XX}(f)$ in nT$^2$ year")
ax_spectrum.set_title("Power spectral density")
ax_spectrum.grid()

fig.tight_layout()
save_figure(fig, "northward_component_psd")

# 5. Period of the highest peak within each period range (in years)
for period_low, period_high in [(0.4, 0.6), (0.8, 1.2), (9, 13)]:
    in_range = (periods >= period_low) & (periods <= period_high)
    peak_period = periods[in_range][np.argmax(psd[in_range])]
    print(
        f"Highest peak between {period_low} and {period_high} years: "
        f"{peak_period:.2f} years"
    )

# Answer 6: The three peaks are found at periods of 0.50, 1.00, and 11.04
# years.
#
# - The 11-year peak is the solar cycle: the activity of the Sun, and hence the
#   intensity of the currents it drives in the ionosphere and the
#   magnetosphere, varies with a period of about 11 years.
# - The 1-year peak is the seasonal variation of these external currents,
#   caused by the tilt of the rotation axis of the Earth with respect to its
#   orbit.
# - The 6-month peak comes from the geomagnetic activity, which is stronger
#   near the equinoxes, when the geometry between the Earth's dipole and the
#   solar wind favors the energy transfer from the solar wind to the
#   magnetosphere.

# 3.3. Filtering

# Question 7: remove the components of X(t) with periods longer than 20 years.
#
# 1. Design a high-pass Butterworth filter of order 1 with a corner period of
#    20 years.
# 2. Apply it with `signal.filtfilt` to `X_detrended`, and store the result
#    in `X_filtered`. We write this filtered signal X_tilde(t).
# 3. In the left panel, plot `X_detrended` and X_tilde(t) as a function of
#    time. In the right panel, plot the power spectral densities P_XX(f) and
#    P_X_tilde(f) as a function of the period with logarithmic axes, together
#    with the filter gain.
# 4. Which peaks of P_XX(f) are preserved by the filter?

# 1. High-pass Butterworth filter with a corner period of 20 years
period_cutoff = 20
filter_order = 1
b, a = signal.butter(
    filter_order, 1 / period_cutoff, btype="highpass", fs=1 / time_step
)

# 2. Apply the filter forward and backward
X_filtered = signal.filtfilt(b, a, X_detrended)

# Power spectral densities (periods computed in the previous cell)
psd = one_sided_psd(X_detrended, time_step)
psd_filtered = one_sided_psd(X_filtered, time_step)

# Filter gain; filtfilt applies the filter twice, which squares the gain
filter_frequencies, filter_response = signal.freqz(b, a, fs=1 / time_step)
filter_frequencies[0] = np.nan
filter_periods = 1 / filter_frequencies
filter_gain = np.abs(filter_response) ** 2

# 3. Plot the signals and their power spectral densities side by side
fig, (ax_time, ax_spectrum) = plt.subplots(ncols=2, figsize=(8, 4))

ax_time.plot(clf.index, X_detrended, label="$X(t)$ (detrended)")
ax_time.plot(clf.index, X_filtered, label=r"$\tilde{X}(t)$")
ax_time.set_xlabel("Time $t$ in years")
ax_time.set_ylabel("Signal amplitude in nT")
ax_time.set_title("Time domain")
ax_time.legend(loc="upper center", bbox_to_anchor=(0.5, -0.2), ncols=2)
ax_time.xaxis.set_major_locator(mdates.YearLocator(20))
ax_time.grid()

ax_spectrum.loglog(periods, psd, label="$P_{XX}(f)$")
ax_spectrum.loglog(periods, psd_filtered, label=r"$P_{\tilde{X}\tilde{X}}(f)$")
ax_spectrum.set_xlabel("Period $T$ in years")
ax_spectrum.set_ylabel("PSD in nT$^2$ year")
ax_spectrum.set_title("Spectral domain")
ax_spectrum.legend(loc="upper center", bbox_to_anchor=(0.5, -0.2), ncols=2)
ax_spectrum.grid()

# Filter gain on a secondary y-axis
ax_filter = ax_spectrum.twinx()
ax_filter.semilogx(filter_periods, filter_gain, color="C2")
ax_filter.axvline(period_cutoff, color="C2", linestyle="--")
ax_filter.set_ylabel(r"Filter gain $|\hat{h}(f)|^2$", color="C2")

fig.tight_layout()
save_figure(fig, "filtered_northward_component")

# 4. Filter gain at the periods of the three peaks
for period in [0.5, 1, 11]:
    gain = np.interp(1 / period, filter_frequencies[1:], filter_gain[1:])
    print(f"Filter gain at {period:4g} years: {gain:.2f}")

# Answer 7: The filter removes most of the power at periods longer than 20
# years, and keeps the peaks at 0.5 and 1 year unchanged. The 11-year peak is
# preserved but slightly attenuated: an order-1 filter has a gentle slope, and
# its gain at 11 years is about 0.77 in amplitude, that is, about 0.6 in power.

# 3.4. Correlating with the sunspot number

# The file data/sunspot_number.dat contains monthly values of the sunspot
# number (a proxy for solar activity) between 1749 and 2025, in two columns
# without header: the date in decimal years, and the sunspot number.
#
# Question 8: compare the filtered northward component X_tilde(t) with the
# sunspot number S(t).
#
# 1. Load the file data/sunspot_number.dat into a DataFrame with
#    `pd.read_fwf`. The dates of the CLF samples in decimal years are given
#    in `clf_decimal_years` (see below).
# 2. Plot S(t) on the left y-axis and X_tilde(t) on a right y-axis created
#    with `ax.twinx()`, over the time span of the CLF record.
# 3. Interpolate S(t) at the dates of the CLF samples with `np.interp`, and
#    compute the Pearson correlation coefficient between S(t) and X_tilde(t)
#    with `np.corrcoef`.
# 4. Are the two signals correlated or anticorrelated? Propose a physical
#    explanation.

# Dates of the CLF samples in decimal years
days_in_year = np.where(clf.index.is_leap_year, 366, 365)
day_fraction = clf.index.dayofyear - 1 + clf.index.hour / 24
clf_decimal_years = clf.index.year + day_fraction / days_in_year

# 1. Load the monthly sunspot number
sunspots = pd.read_fwf(
    "data/sunspot_number.dat", header=None, names=["decimal_year", "number"]
)

# 2. Plot S(t) and the filtered X(t) over the time span of the CLF record
in_clf_span = sunspots["decimal_year"].between(
    clf_decimal_years.min(), clf_decimal_years.max()
)
sunspots_clf = sunspots[in_clf_span]
fig, ax = plt.subplots()
ax.plot(sunspots_clf["decimal_year"], sunspots_clf["number"])
ax.set_xlabel("Time $t$ in years")
ax.set_ylabel("Sunspot number $S(t)$", color="C0")
ax.grid()

ax_twin = ax.twinx()
ax_twin.plot(clf_decimal_years, X_filtered, color="C1")
ax_twin.set_ylabel(r"$\tilde{X}(t)$ in nT", color="C1")
save_figure(fig, "sunspot_correlation")

# 3. Pearson correlation coefficient at the dates of the CLF samples
sunspots_at_clf = np.interp(
    clf_decimal_years, sunspots["decimal_year"], sunspots["number"]
)
correlation = np.corrcoef(sunspots_at_clf, X_filtered)[0, 1]
print(f"Correlation coefficient: {correlation:.2f}")

# Answer 8: The correlation coefficient is about -0.34: we observe an
# anticorrelation between the two signals, which would show even more clearly
# if we were to band-pass filter the signals between 5 and 15 years. At times
# of high solar activity (high sunspot number), the northward component of the
# geomagnetic field is weaker: a hand-waving argument is that stronger activity
# of the Sun leads to a contraction of the geomagnetic field lines; locally
# (for instance in Chambon-la-Forêt) the field becomes more vertical, and its
# horizontal component decreases. The opposite occurs during times of a
# magnetically quiet Sun.
