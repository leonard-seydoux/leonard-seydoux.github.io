"""Basic signal processing with Python: geomagnetic data (section 3).

Script version of the second part of the notebook
lab_1_signal_processing.ipynb, with the same questions. Complete the code
between the "Write your code here" and "End of your code" markers, and write
the answers to the questions as comments. Run with:

    python script_1b_geomagnetic_data.py

Figures are saved as PNG and PDF files in the figures folder instead of being
shown interactively.
"""

import os

import matplotlib.dates as mdates
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
from scipy import signal

# Folder where the figures are saved
FIGURE_FOLDER = "figures"
os.makedirs(FIGURE_FOLDER, exist_ok=True)


def save_figure(fig, name):
    """Save a figure as PNG and PDF in the figure folder, and close it."""
    fig.savefig(os.path.join(FIGURE_FOLDER, f"{name}.png"))
    fig.savefig(os.path.join(FIGURE_FOLDER, f"{name}.pdf"))
    plt.close(fig)


# 3.1. Loading the data

# Load the monthly means (the header of the file spans 9 lines)
clf = pd.read_fwf("data/chambon_la_foret.dat", skiprows=9)

# Build a datetime index from the date and time columns
clf.index = pd.to_datetime(clf["date"] + " " + clf["time"])
clf.index.name = "datetime"
clf = clf.drop(columns=["date", "time", "doy"])

# Name the columns after the geomagnetic elements: horizontal intensity H
# (nT), declination D (minutes of arc), vertical component Z (nT), and total
# intensity F (nT)
clf = clf.rename(columns={"clfh": "H", "clfd": "D", "clfz": "Z", "clff": "F"})

# The value 88888 flags missing values (F is missing before 1981)
clf = clf.replace(88888.0, np.nan)

# Monthly samples; six months are missing (January 2017 to 2021, and February
# 2021), but we neglect these gaps and treat the samples as evenly spaced
time_step = 1 / 12

# Plot the vertical component of the magnetic field
ax = clf["Z"].plot(grid=True)
ax.set_xlabel("Time $t$ in years")
ax.set_ylabel("$Z(t)$ in nT at Chambon-la-Forêt")
save_figure(ax.get_figure(), "vertical_component")

# The "fast" fluctuations of Z are to some extent concealed by a long-term
# trend.
#
# Question 5: remove the linear trend of Z(t) with `signal.detrend`, store the
# result in `Z_detrended`, and plot it as a function of time. Describe the
# variations that become visible once the trend is removed.

#### Write your code here ####


#### End of your code ####

# 3.2. Spectral analysis

# Question 6: analyze the spectrum of the northward component X(t) of the
# magnetic field at CLF.
#
# 1. Compute X = H cos(D), as given in the header of the file
#    data/chambon_la_foret.dat. The declination D is given in minutes of
#    arc: convert it to radians before taking the cosine. Store the result in
#    a new column `clf["X"]`.
# 2. Remove the linear trend of X(t) with `signal.detrend` and store the
#    result in `X_detrended`.
# 3. Compute the one-sided power spectral density P_XX(f) of `X_detrended`,
#    as defined in section 2.3 of the notebook.
# 4. Plot X(t) in the left panel, and P_XX(f) as a function of the period in
#    the right panel, with logarithmic axes.
# 5. Find the period of the highest peak of P_XX(f) within each of the
#    following period ranges: 0.4 to 0.6 years, 0.8 to 1.2 years, and 9 to
#    13 years. Which natural phenomenon causes each of these three peaks?

#### Write your code here ####


#### End of your code ####

# 3.3. Filtering

# Question 7: remove the components of X(t) with periods longer than 20 years.
#
# 1. Design a high-pass Butterworth filter of order 1 with a corner period of
#    20 years.
# 2. Apply it with `signal.filtfilt` to `X_detrended`, and store the result
#    in `X_filtered`. We write this filtered signal X_tilde(t).
# 3. In the left panel, plot `X_detrended` and X_tilde(t) as a function of
#    time. In the right panel, plot the power spectral densities P_XX(f) and
#    P_X_tilde(f) as a function of the period with logarithmic axes, together
#    with the filter gain.
# 4. Which peaks of P_XX(f) are preserved by the filter?

#### Write your code here ####


#### End of your code ####

# 3.4. Correlating with the sunspot number

# The file data/sunspot_number.dat contains monthly values of the sunspot
# number (a proxy for solar activity) between 1749 and 2025, in two columns
# without header: the date in decimal years, and the sunspot number.
#
# Question 8: compare the filtered northward component X_tilde(t) with the
# sunspot number S(t).
#
# 1. Load the file data/sunspot_number.dat into a DataFrame with
#    `pd.read_fwf`. The dates of the CLF samples in decimal years are given
#    in `clf_decimal_years` (see below).
# 2. Plot S(t) on the left y-axis and X_tilde(t) on a right y-axis created
#    with `ax.twinx()`, over the time span of the CLF record.
# 3. Interpolate S(t) at the dates of the CLF samples with `np.interp`, and
#    compute the Pearson correlation coefficient between S(t) and X_tilde(t)
#    with `np.corrcoef`.
# 4. Are the two signals correlated or anticorrelated? Propose a physical
#    explanation.

# Dates of the CLF samples in decimal years
days_in_year = np.where(clf.index.is_leap_year, 366, 365)
day_fraction = clf.index.dayofyear - 1 + clf.index.hour / 24
clf_decimal_years = clf.index.year + day_fraction / days_in_year

#### Write your code here ####


#### End of your code ####
