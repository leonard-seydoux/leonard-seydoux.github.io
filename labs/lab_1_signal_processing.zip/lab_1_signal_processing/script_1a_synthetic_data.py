"""Basic signal processing with Python: synthetic data (section 2).

Script version of the first part of the notebook lab_1_signal_processing.ipynb,
with the same questions. Complete the code between the "Write your code here"
and "End of your code" markers, and write the answers to the questions as
comments. Run with:

    python script_1a_synthetic_data.py

Figures are saved as PNG and PDF files in the figures folder instead of being
shown interactively.
"""

import os

import matplotlib.pyplot as plt
import numpy as np
from scipy import signal

import synthetic

# Folder where the figures are saved
FIGURE_FOLDER = "figures"
os.makedirs(FIGURE_FOLDER, exist_ok=True)


def save_figure(fig, name):
    """Save a figure as PNG and PDF in the figure folder, and close it."""
    fig.savefig(os.path.join(FIGURE_FOLDER, f"{name}.png"))
    fig.savefig(os.path.join(FIGURE_FOLDER, f"{name}.pdf"))
    plt.close(fig)


# 2.1. Synthetic monochromatic signal

# Time vector in decimal years, with one sample per month
time_step = 1 / 12
times = synthetic.time_range(
    time_start=1850, time_end=2010, time_step=time_step
)

# Monochromatic signal with a period of 10 years
monochromatic_period = 10
monochromatic_signal = synthetic.sine(times, period=monochromatic_period)

# Plot
fig, ax = plt.subplots()
ax.plot(times, monochromatic_signal)
ax.set_xlabel("Time $t$ in years")
ax.set_ylabel("Signal amplitude $x(t)$")
ax.set_title("Monochromatic signal")
ax.grid()
save_figure(fig, "monochromatic_signal")

# Question 1: the sampling theorem sets an upper limit on the time step dt.
#
# 1. What is the largest time step dt that can be used to sample the
#    sinusoid of period t_0 = 10 years without aliasing?
# 2. What is the general condition on dt for a sinusoid of any period t_0?
# 3. What does the sampled signal look like when this condition is not
#    satisfied?

#### Write your answer here ####


#### End of your answer ####

# 2.2. Synthetic multi-component signal

# Question 2: create a synthetic signal s(t) made of K = 4 harmonic components
# alpha_i * sin(2 pi t / t_i + phi_i), with periods t_1 = 0.5, t_2 = 1,
# t_3 = 11, and t_4 = 60 years.
#
# 1. Use the time vector `times` defined above (from 1850 to 2010, one sample
#    per month).
# 2. Choose the amplitudes alpha_i and the phases phi_i (in radians) freely.
# 3. Store the periods, amplitudes, and phases in the NumPy arrays
#    `component_periods`, `component_amplitudes`, and `component_phases`.
# 4. Generate each component with `synthetic.sine()` and store their sum in
#    the variable `multi_component_signal`.
# 5. Plot s(t) as a function of time.
#
# The variables of steps 3 and 4 are used in the following questions.

#### Write your code here ####


#### End of your code ####

# 2.3. Spectral analysis

# Spectral amplitude of the monochromatic signal
spectral_amplitude = np.abs(np.fft.rfft(monochromatic_signal))

# Frequencies (in cycles per year) and periods (in years) of the spectrum
frequencies = np.fft.rfftfreq(len(monochromatic_signal), d=time_step)
frequencies[0] = np.nan  # the zero frequency has no finite period
periods = 1 / frequencies

# Plot the signal and its spectrum side by side
fig, (ax_time, ax_spectrum) = plt.subplots(ncols=2, figsize=(8, 3))

ax_time.plot(times, monochromatic_signal)
ax_time.set_xlabel("Time $t$ in years")
ax_time.set_ylabel("Signal amplitude $x(t)$")
ax_time.set_title("Monochromatic signal")
ax_time.grid()

ax_spectrum.semilogx(periods, spectral_amplitude)
ax_spectrum.axvline(monochromatic_period, color="C1", label="True period")
ax_spectrum.set_xlabel("Period $T$ in years")
ax_spectrum.set_ylabel(r"Spectral amplitude $|\hat{x}(f)|$")
ax_spectrum.set_title("Spectrum")
ax_spectrum.legend()
ax_spectrum.grid()

fig.tight_layout()
save_figure(fig, "monochromatic_spectrum")

# Question 3: copy the code above and adapt it to `multi_component_signal`.
#
# 1. Compute the spectral amplitude |s_hat(f)| with `np.fft.rfft`.
# 2. Plot s(t) in the left panel. In the right panel, plot |s_hat(f)| as a
#    function of the period on a logarithmic axis, and mark the four periods
#    t_i with vertical lines.
# 3. Does each spectral peak appear at the expected period?
# 4. A sine of amplitude alpha that spans an integer number of periods over N
#    samples produces a spectral peak of height exactly alpha * N / 2. For
#    each component, compute the ratio between the height of its spectral
#    peak and alpha_i * N / 2. Which peaks deviate the most from this value,
#    and why? Hint: count how many periods of each component fit in the time
#    window of duration N * dt.

#### Write your code here ####


#### End of your code ####

# 2.4. Filtering

# Corner periods of the band-pass filter (in years)
period_min, period_max = 5, 15

# Butterworth band-pass filter, with frequencies in cycles per year
filter_order = 1
b, a = signal.butter(
    filter_order,
    [1 / period_max, 1 / period_min],
    btype="bandpass",
    fs=1 / time_step,
)

# Apply the filter forward and backward (no phase delay)
filtered_signal = signal.filtfilt(b, a, monochromatic_signal)

# Spectral amplitudes of the input and filtered signals
spectral_amplitude = np.abs(np.fft.rfft(monochromatic_signal))
spectral_amplitude_filtered = np.abs(np.fft.rfft(filtered_signal))
frequencies = np.fft.rfftfreq(len(monochromatic_signal), d=time_step)
frequencies[0] = np.nan  # the zero frequency has no finite period
periods = 1 / frequencies

# Filter gain; filtfilt applies the filter twice, which squares the gain
filter_frequencies, filter_response = signal.freqz(b, a, fs=1 / time_step)
filter_frequencies[0] = np.nan
filter_periods = 1 / filter_frequencies
filter_gain = np.abs(filter_response) ** 2

# Plot the signals and their spectra side by side
fig, (ax_time, ax_spectrum) = plt.subplots(ncols=2, figsize=(8, 3))

ax_time.plot(times, monochromatic_signal, label="$x(t)$")
ax_time.plot(times, filtered_signal, label="$y(t)$")
ax_time.set_xlabel("Time $t$ in years")
ax_time.set_ylabel("Signal amplitude")
ax_time.set_title("Time domain")
ax_time.legend(loc="center right")
ax_time.grid()

ax_spectrum.semilogx(periods, spectral_amplitude, label=r"$|\hat{x}(f)|$")
ax_spectrum.semilogx(
    periods, spectral_amplitude_filtered, label=r"$|\hat{y}(f)|$"
)
ax_spectrum.set_xlabel("Period $T$ in years")
ax_spectrum.set_ylabel("Spectral amplitude")
ax_spectrum.set_title("Spectral domain")
ax_spectrum.legend(loc="center right")
ax_spectrum.grid()

# Filter gain on a secondary y-axis
ax_filter = ax_spectrum.twinx()
ax_filter.semilogx(filter_periods, filter_gain, color="C2")
ax_filter.axvline(period_min, color="C2", linestyle="--")
ax_filter.axvline(period_max, color="C2", linestyle="--")
ax_filter.set_ylabel(r"Filter gain $|\hat{h}(f)|^2$", color="C2")

fig.tight_layout()
save_figure(fig, "bandpass_example")

# Question 4: extract the 11-year component x_3(t) from s(t) with the
# band-pass filter above (coefficients `b` and `a`, corner periods of 5 and 15
# years). By default, `signal.filtfilt` extends the signal at both ends with a
# few samples before filtering (argument `padtype="odd"`); the argument
# `padtype=None` disables this extension.
#
# 1. Filter `multi_component_signal` with `signal.filtfilt` and the default
#    arguments, and store the result in `filtered_default`.
# 2. Filter `multi_component_signal` with `signal.filtfilt` and
#    `padtype=None`, and store the result in `filtered_unpadded`.
# 3. In the left panel, plot the true component
#    x_3(t) = alpha_3 * sin(2 pi t / t_3 + phi_3) and the two filtered signals
#    as a function of time. In the right panel, plot the spectral amplitudes
#    of s(t) and of the two filtered signals as a function of the period,
#    together with the filter gain.
# 4. For each filtered signal, compute the root-mean-square (RMS) difference
#    with x_3(t) within the first and last 15 years of the time window, and
#    within the rest of the time window. Where are the filtered signals the
#    furthest from x_3(t)? Which of the two filtering options reduces this
#    difference? Why is the difference not zero in the middle of the time
#    window?

#### Write your code here ####


#### End of your code ####
