"""Basic signal processing with Python: synthetic data (section 2).

Proposed solution of script_1a_synthetic_data.py (section 2). The code and the
answers are the same as in the notebook lab_1_signal_processing_solution.ipynb.
Run with:

    python script_1a_synthetic_data_solution.py

Figures are saved as PNG and PDF files in the figures folder instead of being
shown interactively.
"""

import os

import matplotlib.pyplot as plt
import numpy as np
from scipy import signal

import synthetic

# Folder where the figures are saved
FIGURE_FOLDER = "figures"
os.makedirs(FIGURE_FOLDER, exist_ok=True)


def save_figure(fig, name):
    """Save a figure as PNG and PDF in the figure folder, and close it."""
    fig.savefig(os.path.join(FIGURE_FOLDER, f"{name}.png"))
    fig.savefig(os.path.join(FIGURE_FOLDER, f"{name}.pdf"))
    plt.close(fig)


# 2.1. Synthetic monochromatic signal

# Time vector in decimal years, with one sample per month
time_step = 1 / 12
times = synthetic.time_range(
    time_start=1850, time_end=2010, time_step=time_step
)

# Monochromatic signal with a period of 10 years
monochromatic_period = 10
monochromatic_signal = synthetic.sine(times, period=monochromatic_period)

# Plot
fig, ax = plt.subplots()
ax.plot(times, monochromatic_signal)
ax.set_xlabel("Time $t$ in years")
ax.set_ylabel("Signal amplitude $x(t)$")
ax.set_title("Monochromatic signal")
ax.grid()
save_figure(fig, "monochromatic_signal")

# Question 1: the sampling theorem sets an upper limit on the time step dt.
#
# 1. What is the largest time step dt that can be used to sample the
#    sinusoid of period t_0 = 10 years without aliasing?
# 2. What is the general condition on dt for a sinusoid of any period t_0?
# 3. What does the sampled signal look like when this condition is not
#    satisfied?

# Answer 1:
#
# 1. According to the Nyquist-Shannon sampling theorem, we need strictly more
#    than two samples per period. With t_0 = 10 years, the time step must
#    therefore be strictly smaller than 5 years.
# 2. The general condition is dt < t_0 / 2, or equivalently, the sampling
#    frequency 1/dt must be larger than twice the frequency 1/t_0 of the
#    sinusoid.
# 3. The samples are then identical to those of a sinusoid with a longer
#    period: this is aliasing. The frequency 1/t_0 appears folded back into the
#    interval [0, 1/(2dt)].

# 2.2. Synthetic multi-component signal

# Question 2: create a synthetic signal s(t) made of K = 4 harmonic components
# alpha_i * sin(2 pi t / t_i + phi_i), with periods t_1 = 0.5, t_2 = 1,
# t_3 = 11, and t_4 = 60 years.
#
# 1. Use the time vector `times` defined above (from 1850 to 2010, one sample
#    per month).
# 2. Choose the amplitudes alpha_i and the phases phi_i (in radians) freely.
# 3. Store the periods, amplitudes, and phases in the NumPy arrays
#    `component_periods`, `component_amplitudes`, and `component_phases`.
# 4. Generate each component with `synthetic.sine()` and store their sum in
#    the variable `multi_component_signal`.
# 5. Plot s(t) as a function of time.
#
# The variables of steps 3 and 4 are used in the following questions.

# Periods (in years), amplitudes, and phases (in radians) of the components
component_periods = np.array([0.5, 1, 11, 60])
component_amplitudes = np.array([0.5, 1, 2, 1])
component_phases = np.array([0, np.pi / 4, np.pi / 2, 0])

# Sum the components
multi_component_signal = np.zeros_like(times)
for period, amplitude, phase in zip(
    component_periods, component_amplitudes, component_phases
):
    multi_component_signal += synthetic.sine(
        times, period=period, amplitude=amplitude, phase=phase
    )

# Plot
fig, ax = plt.subplots()
ax.plot(times, multi_component_signal)
ax.set_xlabel("Time $t$ in years")
ax.set_ylabel("Signal amplitude $s(t)$")
ax.set_title("Multi-component signal")
ax.grid()
save_figure(fig, "multi_component_signal")

# 2.3. Spectral analysis

# Spectral amplitude of the monochromatic signal
spectral_amplitude = np.abs(np.fft.rfft(monochromatic_signal))

# Frequencies (in cycles per year) and periods (in years) of the spectrum
frequencies = np.fft.rfftfreq(len(monochromatic_signal), d=time_step)
frequencies[0] = np.nan  # the zero frequency has no finite period
periods = 1 / frequencies

# Plot the signal and its spectrum side by side
fig, (ax_time, ax_spectrum) = plt.subplots(ncols=2, figsize=(8, 3))

ax_time.plot(times, monochromatic_signal)
ax_time.set_xlabel("Time $t$ in years")
ax_time.set_ylabel("Signal amplitude $x(t)$")
ax_time.set_title("Monochromatic signal")
ax_time.grid()

ax_spectrum.semilogx(periods, spectral_amplitude)
ax_spectrum.axvline(monochromatic_period, color="C1", label="True period")
ax_spectrum.set_xlabel("Period $T$ in years")
ax_spectrum.set_ylabel(r"Spectral amplitude $|\hat{x}(f)|$")
ax_spectrum.set_title("Spectrum")
ax_spectrum.legend()
ax_spectrum.grid()

fig.tight_layout()
save_figure(fig, "monochromatic_spectrum")

# Question 3: copy the code above and adapt it to `multi_component_signal`.
#
# 1. Compute the spectral amplitude |s_hat(f)| with `np.fft.rfft`.
# 2. Plot s(t) in the left panel. In the right panel, plot |s_hat(f)| as a
#    function of the period on a logarithmic axis, and mark the four periods
#    t_i with vertical lines.
# 3. Does each spectral peak appear at the expected period?
# 4. A sine of amplitude alpha that spans an integer number of periods over N
#    samples produces a spectral peak of height exactly alpha * N / 2. For
#    each component, compute the ratio between the height of its spectral
#    peak and alpha_i * N / 2. Which peaks deviate the most from this value,
#    and why? Hint: count how many periods of each component fit in the time
#    window of duration N * dt.

# Spectral amplitude of the multi-component signal
n_samples = len(multi_component_signal)
spectral_amplitude = np.abs(np.fft.rfft(multi_component_signal))

# Frequencies (in cycles per year) and periods (in years) of the spectrum
frequencies = np.fft.rfftfreq(n_samples, d=time_step)
frequencies[0] = np.nan  # the zero frequency has no finite period
periods = 1 / frequencies

# Plot the signal and its spectrum side by side
fig, (ax_time, ax_spectrum) = plt.subplots(ncols=2, figsize=(8, 3))

ax_time.plot(times, multi_component_signal)
ax_time.set_xlabel("Time $t$ in years")
ax_time.set_ylabel("Signal amplitude $s(t)$")
ax_time.set_title("Multi-component signal")
ax_time.grid()

ax_spectrum.semilogx(periods, spectral_amplitude)
for index, period in enumerate(component_periods):
    label = "True periods" if index == 0 else None
    ax_spectrum.axvline(period, color="C1", label=label)
ax_spectrum.set_xlabel("Period $T$ in years")
ax_spectrum.set_ylabel(r"Spectral amplitude $|\hat{s}(f)|$")
ax_spectrum.set_title("Spectrum")
ax_spectrum.legend()
ax_spectrum.grid()

fig.tight_layout()
save_figure(fig, "multi_component_spectrum")

# Compare the height of each peak with the expected value alpha * N / 2
for period, amplitude in zip(component_periods, component_amplitudes):
    in_peak = (periods > 0.8 * period) & (periods < 1.2 * period)
    peak_height = spectral_amplitude[in_peak].max()
    expected_height = amplitude * n_samples / 2
    print(
        f"Period {period:4g} years: peak height is "
        f"{peak_height / expected_height:.0%} of alpha * N / 2"
    )

# Answer 3:
#
# 3. Yes, the four peaks appear at the expected periods. The peaks at long
#    periods look wider, because the DFT only samples the periods N * dt / k
#    (with k an integer), which are sparse at long periods.
# 4. The ratios are about 95%, 99%, 69%, and 88% for the periods 0.5, 1, 11,
#    and 60 years. The time window lasts N * dt ~ 160.1 years, so the
#    components fit about 320.2, 160.1, 14.55, and 2.67 times in it. When this
#    number is close to an integer (0.5 and 1 year), the frequency of the
#    component almost coincides with a DFT frequency, and the peak almost
#    reaches alpha_i * N / 2. The 11-year component falls halfway between two
#    DFT frequencies: its energy is split between the neighboring frequencies
#    (spectral leakage), and its peak is the lowest. The 60-year component lies
#    in between.

# 2.4. Filtering

# Corner periods of the band-pass filter (in years)
period_min, period_max = 5, 15

# Butterworth band-pass filter, with frequencies in cycles per year
filter_order = 1
b, a = signal.butter(
    filter_order,
    [1 / period_max, 1 / period_min],
    btype="bandpass",
    fs=1 / time_step,
)

# Apply the filter forward and backward (no phase delay)
filtered_signal = signal.filtfilt(b, a, monochromatic_signal)

# Spectral amplitudes of the input and filtered signals
spectral_amplitude = np.abs(np.fft.rfft(monochromatic_signal))
spectral_amplitude_filtered = np.abs(np.fft.rfft(filtered_signal))
frequencies = np.fft.rfftfreq(len(monochromatic_signal), d=time_step)
frequencies[0] = np.nan  # the zero frequency has no finite period
periods = 1 / frequencies

# Filter gain; filtfilt applies the filter twice, which squares the gain
filter_frequencies, filter_response = signal.freqz(b, a, fs=1 / time_step)
filter_frequencies[0] = np.nan
filter_periods = 1 / filter_frequencies
filter_gain = np.abs(filter_response) ** 2

# Plot the signals and their spectra side by side
fig, (ax_time, ax_spectrum) = plt.subplots(ncols=2, figsize=(8, 3))

ax_time.plot(times, monochromatic_signal, label="$x(t)$")
ax_time.plot(times, filtered_signal, label="$y(t)$")
ax_time.set_xlabel("Time $t$ in years")
ax_time.set_ylabel("Signal amplitude")
ax_time.set_title("Time domain")
ax_time.legend(loc="center right")
ax_time.grid()

ax_spectrum.semilogx(periods, spectral_amplitude, label=r"$|\hat{x}(f)|$")
ax_spectrum.semilogx(
    periods, spectral_amplitude_filtered, label=r"$|\hat{y}(f)|$"
)
ax_spectrum.set_xlabel("Period $T$ in years")
ax_spectrum.set_ylabel("Spectral amplitude")
ax_spectrum.set_title("Spectral domain")
ax_spectrum.legend(loc="center right")
ax_spectrum.grid()

# Filter gain on a secondary y-axis
ax_filter = ax_spectrum.twinx()
ax_filter.semilogx(filter_periods, filter_gain, color="C2")
ax_filter.axvline(period_min, color="C2", linestyle="--")
ax_filter.axvline(period_max, color="C2", linestyle="--")
ax_filter.set_ylabel(r"Filter gain $|\hat{h}(f)|^2$", color="C2")

fig.tight_layout()
save_figure(fig, "bandpass_example")

# Question 4: extract the 11-year component x_3(t) from s(t) with the
# band-pass filter above (coefficients `b` and `a`, corner periods of 5 and 15
# years). By default, `signal.filtfilt` extends the signal at both ends with a
# few samples before filtering (argument `padtype="odd"`); the argument
# `padtype=None` disables this extension.
#
# 1. Filter `multi_component_signal` with `signal.filtfilt` and the default
#    arguments, and store the result in `filtered_default`.
# 2. Filter `multi_component_signal` with `signal.filtfilt` and
#    `padtype=None`, and store the result in `filtered_unpadded`.
# 3. In the left panel, plot the true component
#    x_3(t) = alpha_3 * sin(2 pi t / t_3 + phi_3) and the two filtered signals
#    as a function of time. In the right panel, plot the spectral amplitudes
#    of s(t) and of the two filtered signals as a function of the period,
#    together with the filter gain.
# 4. For each filtered signal, compute the root-mean-square (RMS) difference
#    with x_3(t) within the first and last 15 years of the time window, and
#    within the rest of the time window. Where are the filtered signals the
#    furthest from x_3(t)? Which of the two filtering options reduces this
#    difference? Why is the difference not zero in the middle of the time
#    window?

# True 11-year component, for reference
true_component = synthetic.sine(
    times,
    period=component_periods[2],
    amplitude=component_amplitudes[2],
    phase=component_phases[2],
)

# 1. Filter with the default extension of the signal
filtered_default = signal.filtfilt(b, a, multi_component_signal)

# 2. Filter without extension
filtered_unpadded = signal.filtfilt(b, a, multi_component_signal, padtype=None)

# Spectral amplitudes
spectral_amplitude = np.abs(np.fft.rfft(multi_component_signal))
spectral_amplitude_default = np.abs(np.fft.rfft(filtered_default))
spectral_amplitude_unpadded = np.abs(np.fft.rfft(filtered_unpadded))
frequencies = np.fft.rfftfreq(len(multi_component_signal), d=time_step)
frequencies[0] = np.nan  # the zero frequency has no finite period
periods = 1 / frequencies

# 3. Plot the signals and their spectra side by side
fig, (ax_time, ax_spectrum) = plt.subplots(ncols=2, figsize=(8, 4.5))

ax_time.plot(times, true_component, "k", label="$x_3(t)$ (true)")
ax_time.plot(times, filtered_default, label="Default extension")
ax_time.plot(times, filtered_unpadded, label="No extension")
ax_time.set_xlabel("Time $t$ in years")
ax_time.set_ylabel("Signal amplitude")
ax_time.set_title("Time domain")
ax_time.legend(loc="upper center", bbox_to_anchor=(0.5, -0.2))
ax_time.grid()

ax_spectrum.semilogx(periods, spectral_amplitude, "k", label="$s(t)$")
ax_spectrum.semilogx(
    periods, spectral_amplitude_default, label="Default extension"
)
ax_spectrum.semilogx(
    periods, spectral_amplitude_unpadded, label="No extension"
)
ax_spectrum.set_xlabel("Period $T$ in years")
ax_spectrum.set_ylabel("Spectral amplitude")
ax_spectrum.set_title("Spectral domain")
ax_spectrum.legend(loc="upper center", bbox_to_anchor=(0.5, -0.2))
ax_spectrum.grid()

# Filter gain on a secondary y-axis (computed in the previous cell)
ax_filter = ax_spectrum.twinx()
ax_filter.semilogx(filter_periods, filter_gain, color="C2")
ax_filter.axvline(period_min, color="C2", linestyle="--")
ax_filter.axvline(period_max, color="C2", linestyle="--")
ax_filter.set_ylabel(r"Filter gain $|\hat{h}(f)|^2$", color="C2")

fig.tight_layout()
save_figure(fig, "filtered_11_year_component")

# 4. RMS difference with the true component, near the edges (first and
# last 15 years) and in the middle of the time window
near_edges = (times < times[0] + 15) | (times > times[-1] - 15)
for name, filtered in [
    ("Default extension", filtered_default),
    ("No extension", filtered_unpadded),
]:
    difference = filtered - true_component
    rms_edges = np.sqrt(np.mean(difference[near_edges] ** 2))
    rms_middle = np.sqrt(np.mean(difference[~near_edges] ** 2))
    print(
        f"{name}: RMS difference {rms_edges:.2f} near the edges, "
        f"{rms_middle:.2f} in the middle"
    )

# Answer 4: The filtered signals are the furthest from x_3(t) near the edges of
# the time window. There, the filter responds to the abrupt start and end of
# the signal (edge effects). The default extension of `filtfilt` continues the
# signal smoothly beyond its ends, which reduces these transients: the RMS
# difference near the edges is about 0.24 with the default extension, against
# 0.40 without it. In the middle of the time window, the RMS difference is
# about 0.21 for both options, because the filter gain at 11 years is not
# exactly 1, and because the filter lets part of the other components through
# (mostly the 60-year component).
