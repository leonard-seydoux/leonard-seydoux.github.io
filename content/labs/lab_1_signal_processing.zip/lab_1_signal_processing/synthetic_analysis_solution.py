"""Basic signal processing with Python -- synthetic data (solution).

Run with:
    python synthetic_analysis_solution.py

Figures are saved in the current directory instead of being shown interactively,
Open them from a second terminal that has remote display properly set up. 
"""


import matplotlib.pyplot as plt
import numpy as np
from scipy import signal
import synthetic

#
# -----------------------------------------------------------------------
# 2.1. Synthetic monochromatic signal
# -----------------------------------------------------------------------
# An example of how to use the synthetic module 
# Time vector of the timeseries (in decimal years)
dt = 1 / 12
times = synthetic.time_range(time_start=1850, time_end=2010, time_step=dt)

# Generate a synthetic time series with 10-year period
single_component_period = 10
single_component = synthetic.sine(times, period=single_component_period)

# Plot
fig, ax = plt.subplots()
ax.plot(times, single_component)
ax.set_xlabel("time $t$ in years")
ax.set_ylabel("signal amplitude $x(t)$")
ax.set_title("Single-component signal")
fig.tight_layout()
plt.savefig("single_component.png")
plt.savefig("single_component.pdf")
plt.close(fig)

# Question 1: what is the maximum time step dt that can be used to sample
# the synthetic time series correctly? Derive a general formula for the
# maximum time step admissible for a monochromatic time series of period
# t_0. What effect do you expect to observe if the time step is too large?

# Answer 1: according to the Shannon-Nyquist theorem, the time step must be
# strictly smaller than half the period of the signal. Here t_0 = 10 years,
# so dt < 5 years. In general, dt < t_0 / 2. If the time step is too large,
# aliasing effects are expected in the time series.

# -----------------------------------------------------------------------
# 2.2. Synthetic multi-component signal
# -----------------------------------------------------------------------

# Question 2: build s(t) spanning 1850-2010, one point per month, with
# four harmonic components of periods 0.5, 1, 11, and 60 years.
# Do not forget to plot the corresponding timeseries.  
#### Solution ####
my_periods = np.array([0.5, 1, 11, 60])
my_phases = np.array([0, 0, 0, 0])
my_amplitudes = np.array([1, 0.5, 2, 0.1])
components = np.zeros((len(my_periods), len(times)), dtype=float)
for i, period in enumerate(my_periods):
    components[i, :] = synthetic.sine(times, period=period, phase=my_phases[i])

# Combine components into a single signal
my_signal = np.dot(my_amplitudes, components)
# equivalent my_signal = my_amplitudes @ components

# Plot
fig, ax = plt.subplots()
ax.plot(times, my_signal)
ax.set_xlabel("time $t$ in years")
ax.set_ylabel("signal amplitude $s(t)$")
ax.set_title("Multi-component signal")
fig.tight_layout()
plt.savefig("multi_component.png")
plt.savefig("multi_component.pdf")
plt.close(fig)
#### End of solution ####

# -----------------------------------------------------------------------
# 2.3. Spectral analysis
# -----------------------------------------------------------------------

# Compute the Fourier transform of the monochromatic signal x(t)
n_fft = len(times)
spectrum = np.fft.rfft(single_component, n=n_fft)
spectral_amplitude = np.abs(spectrum)

# Calculate periods
frequencies = np.fft.rfftfreq(n_fft, d=dt)
frequencies[0] = np.nan
periods = 1 / frequencies  # Avoid division by zero

# Prepare the plot
fig, ax = plt.subplots(ncols=2, figsize=(8, 3))

# Plot the signal
ax[0].plot(times, single_component)
ax[0].set_xlabel("time $t$ in years")
ax[0].set_ylabel("signal amplitude $x(t)$")
ax[0].set_title("Single-component signal")
ax[0].grid()

# Plot the spectrum
ax[1].axvline(single_component_period, color="C1", label="True period")
ax[1].semilogx(periods, np.abs(spectrum))
ax[1].set_xlabel("Period $T$ in years")
ax[1].set_ylabel(r"Spectral amplitude $|\hat{x}(f)|$")
ax[1].set_title("Single-component signal spectrum")
ax[1].grid()
ax[1].legend()

fig.tight_layout()
plt.savefig("single_component_spectrum.png")
plt.savefig("single_component_spectrum.pdf")
plt.close(fig)

# Question 3: adapt the code above to the multi-component signal s(t)
# built in Question 2. Plot its spectrum. What do you observe? 

#### Solution ####
# Compute the Fourier transform of the multi-component signal s(t)
n_fft = len(times)
spectrum = np.fft.rfft(my_signal, n=n_fft)
spectral_amplitude = np.abs(spectrum)

# Calculate periods
frequencies = np.fft.rfftfreq(n_fft, d=dt)
frequencies[0] = np.nan
periods = 1 / frequencies  # Avoid division by zero

# Prepare the plot
fig, ax = plt.subplots(ncols=2, figsize=(8, 3))

# Plot the signal
ax[0].plot(times, my_signal)
ax[0].set_xlabel("time $t$ in years")
ax[0].set_ylabel("signal amplitude $s(t)$")
ax[0].set_title("Multi-component signal")
ax[0].grid()

# Plot the spectrum
for k, period in enumerate(my_periods):
    if k == 0:
        ax[1].axvline(period, color="C1", label="True periods")
    else:
        ax[1].axvline(period, color="C1")
ax[1].semilogx(periods, np.abs(spectrum))
ax[1].set_xlabel("Period $T$ in years")
ax[1].set_ylabel(r"Spectral amplitude $|\hat{s}(f)|$")
ax[1].set_title("Multi-component signal spectrum")
ax[1].grid()
ax[1].legend()

fig.tight_layout()
plt.savefig("multi_component_spectrum.png")
plt.savefig("multi_component_spectrum.pdf")
plt.close(fig)
#### End of solution ####

# -----------------------------------------------------------------------
# 2.4. Filtering
# -----------------------------------------------------------------------

# Example: bandpass filter with corner periods 5 and 15 years, applied
# to the monochromatic signal x(t).

period_min, period_max = 5, 15

# Get the Nyquist frequency for expressing the filter in normalized units
nyquist = 1 / (2 * dt)
frequency_low = 1 / period_max / nyquist
frequency_high = 1 / period_min / nyquist

# Filter the signal
filter_order = 1
b, a = signal.butter(filter_order, [frequency_low, frequency_high], btype="bandpass")
filtered = signal.filtfilt(b, a, single_component)

# Get spectrum
spectral_amplitude = np.abs(np.fft.rfft(single_component))
spectral_amplitude_filtered = np.abs(np.fft.rfft(filtered))
frequencies = np.fft.rfftfreq(len(single_component), dt)
frequencies[0] = np.nan
periods = 1 / frequencies

# Get filter spectrum
filter_frequencies, filter_spectrum = signal.freqz(b, a, fs=2 * nyquist)
filter_frequencies[0] = np.nan
filter_periods = 1 / filter_frequencies
filter_transmission = np.abs(filter_spectrum)

# Prepare the plot
fig, ax = plt.subplots(ncols=2, figsize=(8, 3))

# Plot the time series
ax[0].plot(times, single_component, label="$x(t)$")
ax[0].plot(times, filtered, label="$y(t)$")
ax[0].set_xlabel("time $t$ in years")
ax[0].set_ylabel("signal amplitude")
ax[0].set_title("Time domain")
ax[0].legend(loc="center right")
ax[0].grid()

# Plot the spectrum
ax[1].semilogx(periods, spectral_amplitude, label=r"$|\hat{x}(f)|$")
ax[1].semilogx(periods, spectral_amplitude_filtered, label=r"$|\hat{y}(f)|$")
ax[1].set_xlabel("period $T$ in years")
ax[1].set_ylabel("spectral amplitude")
ax[1].set_title("Spectral domain")
ax[1].legend(loc="center right")
ax[1].grid()

# Twin axes for the filter
ax_filter = ax[1].twinx()
ax_filter.semilogx(filter_periods, filter_transmission, "C2")
ax_filter.set_ylabel(r"Filter amplitude $|\hat{h}(f)|$", color="C2")
ax_filter.axvline(period_min, color="C2", linestyle="--")
ax_filter.axvline(period_max, color="C2", linestyle="--")

fig.tight_layout()
plt.savefig("./bandpass_example.png")
plt.savefig("./bandpass_example.pdf")
plt.close(fig)

# Question 4: extract the 11-year component of s(t). Plot the filtered
# signal against the original one, and compare their spectra. Then
# improve the reconstruction (e.g. by padding the timeseries) and
# comment on the difference.

#### Solution ####
# Bandpass filter with corner periods 5 and 15 years around the 11-year component
period_min, period_max = 5, 15

# Get the Nyquist frequency for expressing the filter in normalized units
nyquist = 1 / (2 * dt)
frequency_low = 1 / period_max / nyquist
frequency_high = 1 / period_min / nyquist

# Filter the signal
b, a = signal.butter(1, [frequency_low, frequency_high], btype="bandpass")
filtered = signal.filtfilt(b, a, my_signal)

# Improve the reconstruction near the edges: by default, filtfilt extends the
# signal by only 3 * max(len(a), len(b)) samples before filtering. Extend it
# by as many samples as possible (padlen), with a mirror extension
# (padtype="even"). Note that padlen alone, with the default odd extension,
# does not reduce the edge effects here.
filtered_padded = signal.filtfilt(
    b, a, my_signal, padlen=len(my_signal) - 1, padtype="even"
)

# True 11-year component, for reference
true_component = my_amplitudes[2] * components[2]

# Get spectrum
n_fft = len(my_signal)
npad = 0  # number of zeros used to pad the timeseries before the FFT
spectral_amplitude = np.abs(np.fft.rfft(my_signal, n=n_fft + npad))
spectral_amplitude_filtered = np.abs(np.fft.rfft(filtered, n=n_fft + npad))
spectral_amplitude_padded = np.abs(np.fft.rfft(filtered_padded, n=n_fft + npad))
frequencies = np.fft.rfftfreq(n_fft + npad, dt)
frequencies[0] = np.nan
periods = 1 / frequencies

# Get filter spectrum
filter_frequencies, filter_spectrum = signal.freqz(b, a, fs=2 * nyquist)
filter_frequencies[0] = np.nan
filter_periods = 1 / filter_frequencies
filter_transmission = np.abs(filter_spectrum)

# Prepare the plot
fig, ax = plt.subplots(ncols=2, figsize=(10, 4))

# Plot the time series
ax[0].plot(times, my_signal, color="0.8", lw=0.5, label="$s(t)$")
ax[0].plot(times, filtered, color="C1", label="$s_{filt}(t)$")
ax[0].plot(times, filtered_padded, color="C3", label="$s_{filt}(t)$, padded")
ax[0].plot(times, true_component, "k--", lw=1, label="true 11-year component")
ax[0].set_xlabel("time $t$ in years")
ax[0].set_ylabel("signal amplitude")
ax[0].set_title("Time domain")
ax[0].legend(loc="upper right", fontsize="small")
ax[0].grid()

# Plot the spectrum
ax[1].semilogx(periods, spectral_amplitude, label=r"$|\hat{s}(f)|$")
ax[1].semilogx(periods, spectral_amplitude_filtered, label=r"$|\hat{s}_{filt}(f)|$")
ax[1].semilogx(periods, spectral_amplitude_padded, color="C3", label=r"$|\hat{s}_{filt}(f)|$, padded")
ax[1].set_xlabel("period $T$ in years")
ax[1].set_ylabel("spectral amplitude")
ax[1].set_title("Spectral domain")
ax[1].legend(loc="upper right", fontsize="small")
ax[1].grid()

# Twin axes for the filter
ax_filter = ax[1].twinx()
ax_filter.semilogx(filter_periods, filter_transmission, "C2")
ax_filter.set_ylabel(r"Filter amplitude $|\hat{h}(f)|$", color="C2")
ax_filter.axvline(period_min, color="C2", linestyle="--")
ax_filter.axvline(period_max, color="C2", linestyle="--")

fig.tight_layout()
plt.savefig("bandpass_11_years.png")
plt.savefig("bandpass_11_years.pdf")
plt.close(fig)
#### End of solution ####
