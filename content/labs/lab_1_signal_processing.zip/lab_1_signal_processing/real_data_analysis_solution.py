"""Basic signal processing with Python -- real geomagnetic data (solution).

Run with:
    python real_data_analysis_solution.py

"""

import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
from scipy import signal

# -----------------------------------------------------------------------
# 3.1. Loading the data
# -----------------------------------------------------------------------

# Path to the data
filename = "data/chambon_la_foret.dat"

# Load the data
data = pd.read_fwf(filename, skiprows=9, strip=True)

# Turn years into datetime objects
# First, concatenate the year and month columns
date_time_concatenated = data.date.astype(str) + " " + data.time.astype(str)

# Then, convert to datetime objects
data["datetime"] = pd.to_datetime(date_time_concatenated)

# Drop the columns that are not needed anymore
data.drop(["date", "time", "doy"], axis=1, inplace=True)

# Set the datetime column as index
data.set_index("datetime", inplace=True)

# Sampling interval: one value per month (in years)
dt = 1 / 12

# Plot the vertical component of the magnetic field
ax = data.clfz.plot(grid=True, ylabel="$Z(t)$ in nT at Chambon-la-Foret")
ax.set_xlabel("Time $t$ in years")
fig = ax.get_figure()
fig.tight_layout()
plt.savefig("clfz_raw.png")
plt.savefig("clfz_raw.pdf")
plt.close(fig)

# Detrend Z(t) with scipy.signal.detrend and plot the detrended signal.

#### Solution ####
Z_detrended = signal.detrend(data.clfz)

# Plot the detrended data
fig, ax = plt.subplots()
ax.plot(data.index, Z_detrended, label="Detrended $Z(t)$")
ax.set_xlabel("Time $t$ in years")
ax.set_ylabel("Detrended $Z(t)$ in nT at Chambon-la-Foret")
ax.legend(loc="best")
fig.tight_layout()
plt.savefig("clfz_detrended.png")
plt.savefig("clfz_detrended.pdf")
plt.close(fig)
#### End of solution ####

# -----------------------------------------------------------------------
# 3.2. Spectral analysis
# -----------------------------------------------------------------------

# Question 5: compute and plot X(t), the Northward component, from
# X = H * cos(D) (see the header of data/chambon_la_foret.dat; D is in
# minutes of arc and must be converted to degrees, then radians).
# Compute X_hat(f) and plot the power spectral density |X_hat|^2(f),
# ideally alongside X(t) on the same figure. Discuss the peaks you see.

#### Solution ####
# Compute X = H * cos(D), where D is the declination and H the horizontal
# component of the geomagnetic field. D is in minutes of arc.
data["clfx"] = data.clfh * np.cos(np.deg2rad(data.clfd / 60))

# Compute the Fourier spectrum of X
n_fft = len(data.clfx)
n_pad = 0  # number of zeros used to pad the timeseries before the FFT
spectrum = np.fft.rfft(data.clfx, n=n_fft + n_pad)
PSD = np.abs(spectrum) ** 2 / n_fft / dt  # Power Spectral Density

# Calculate periods
frequencies = np.fft.rfftfreq(n_fft + n_pad, d=dt)
frequencies[0] = np.nan
periods = 1 / frequencies  # Avoid division by zero

# Prepare the plot
fig, ax = plt.subplots(ncols=2, figsize=(10, 3))

# Plot the signal
ax[0].plot(data.index, data.clfx)
ax[0].set_title("Signal $X(t)$")
ax[0].set_xlabel("Time $t$ in years")
ax[0].set_ylabel(r"$X$ in nT")
ax[0].grid()

# Plot the spectrum
ax[1].loglog(periods, PSD)
ax[1].set_title("Power Spectral Density of $X(t)$")
ax[1].set_xlabel("Period $T$ in years")
ax[1].set_ylabel(r"PSD in nT$^2$/year")
ax[1].grid()

fig.tight_layout()
plt.savefig("clfx_spectrum.png")
plt.savefig("clfx_spectrum.pdf")
plt.close(fig)
#### End of solution ####

# -----------------------------------------------------------------------
# 3.3. Filtering
# -----------------------------------------------------------------------

# Question 5 (continued): filter out the long-period component of X(t),
# keeping periods shorter than about 20 years. Plot the original
# (possibly detrended) X(t) and its filtered version X_tilde(t) on one
# graph, and the spectra |X_hat|^2(f) and |X_tilde_hat|^2(f) on a
# second graph (both graphs on the same figure).

#### Solution ####
period_max = 20  # years

# Get the Nyquist frequency for expressing the filter in normalized units
nyquist = 1 / (2 * dt)
frequency_low = 1 / period_max / nyquist

# We want to filter out the long-period components, so we use a high-pass filter
filter_order = 1
b, a = signal.butter(filter_order, frequency_low, btype="highpass")
filtered = signal.filtfilt(b, a, data.clfx)

# Get spectrum
clfx_detrended = signal.detrend(data.clfx)
n_fft = len(clfx_detrended)
npad = 0 * n_fft  # zero-padding (e.g. npad = n_fft) gives a smoother spectrum
spectral_amplitude = np.abs(np.fft.rfft(clfx_detrended, n=n_fft + npad))
spectral_amplitude_filtered = np.abs(np.fft.rfft(filtered, n=n_fft + npad))
frequencies = np.fft.rfftfreq(n_fft + npad, dt)
frequencies[0] = np.nan
periods = 1 / frequencies

# Get filter spectrum
filter_frequencies, filter_spectrum = signal.freqz(b, a, fs=2 * nyquist)
filter_frequencies[0] = np.nan
filter_periods = 1 / filter_frequencies
filter_transmission = np.abs(filter_spectrum)

# Prepare the plot
fig, ax = plt.subplots(ncols=2, figsize=(12, 5))

# Plot the time series, removing the linear trend to better see the variations
ax[0].plot(data.index, clfx_detrended, label="$X(t)$ - linear trend")
ax[0].plot(data.index, filtered, label=r"$\tilde X(t)$")
ax[0].set_xlabel("Time $t$ in years")
ax[0].set_ylabel("Signal amplitude")
ax[0].set_title("Time domain")
ax[0].legend(loc="best")
ax[0].grid()

# Plot the spectrum
PSD = spectral_amplitude**2 / len(data.clfx) / dt
PSD_filtered = spectral_amplitude_filtered**2 / len(data.clfx) / dt
ax[1].loglog(periods, PSD, label=r"$|\hat{X}(f)|^2$")
ax[1].loglog(periods, PSD_filtered, label=r"$|\hat{\tilde X}(f)|^2$")
ax[1].set_xlabel("Period $T$ in years")
ax[1].set_ylabel("Power Spectral Density")
ax[1].set_title("Spectral domain")
ax[1].legend(loc="best")
ax[1].grid()

# Twin axes for the filter
ax_filter = ax[1].twinx()
ax_filter.semilogx(filter_periods, filter_transmission, "C2")
ax_filter.set_ylabel(r"Filter amplitude $|\hat{h}(f)|$", color="C2")
ax_filter.axvline(period_max, color="C2", linestyle="--")

fig.tight_layout()
plt.savefig("clfx_filtered.png")
plt.savefig("clfx_filtered.pdf")
plt.close(fig)
#### End of solution ####

# -----------------------------------------------------------------------
# 3.4. Correlating with the sunspot number
# -----------------------------------------------------------------------

# Convert the datetime index to decimal years
dyear_clf = data.index.year + (data.index.dayofyear - 1) / 365

# Parse date from decimal year
sun_spots = pd.read_fwf("data/sunspot_number.dat")
sun_spots.columns = ["decimal_year", "sun_spot_number"]

# Select data within period range of interest
sun_spots = sun_spots[
    (sun_spots.decimal_year >= dyear_clf.min())
    & (sun_spots.decimal_year <= dyear_clf.max())
]

fig, ax = plt.subplots(figsize=(10, 5))
ax.plot(sun_spots["decimal_year"], sun_spots["sun_spot_number"], label="SSN")
ax.legend(loc="best")

ax2 = ax.twinx()

# Question 6: plot the filtered X_tilde(t) on top, using the secondary
# y-axis ax2. What do you observe? Propose an explanation.

#### Solution ####
ax2.plot(dyear_clf, filtered, color="C1", label=r"$\tilde X$")
ax2.set_ylabel(r"$\tilde X(t)$ in nT", color="C1")
ax2.legend(loc="best")
#### End of solution ####

# Label
ax.set_xlabel("Time $t$ in years")
ax.set_ylabel("Sun spot number $S(t)$")
ax.grid()

fig.tight_layout()
plt.savefig("sunspot_correlation.png")
plt.savefig("sunspot_correlation.pdf")
plt.close(fig)

# Answer 6: we observe an anticorrelation between the two signals, which would
# show even more clearly if we were to bandpass the signals between 5 and 15
# years. At times of high solar activity (high sunspot number), the northward
# component of the geomagnetic field is weaker: an arm-waving argument is that
# stronger activity of the Sun leads to a contraction of the geomagnetic field
# lines; locally (for instance in Chambon-la-Foret) the field becomes more
# vertical, and its horizontal component decreases. The opposite occurs during
# times of a magnetically quiet Sun.
