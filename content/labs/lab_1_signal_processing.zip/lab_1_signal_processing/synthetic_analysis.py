"""Basic signal processing with Python -- synthetic data.

Run with:
    python synthetic_analysis.py

Figures are saved in the current directory instead of being shown interactively,
Open them from a second terminal that has remote display properly set up. 
"""


import matplotlib.pyplot as plt
import numpy as np
from scipy import signal
import synthetic

#
# -----------------------------------------------------------------------
# 2.1. Synthetic monochromatic signal
# -----------------------------------------------------------------------
# An example of how to use the synthetic module 
# Time vector of the timeseries (in decimal years)
dt = 1 / 12
times = synthetic.time_range(time_start=1850, time_end=2010, time_step=dt)

# Generate a synthetic time series with 10-year period
single_component_period = 10
single_component = synthetic.sine(times, period=single_component_period)

# Plot
fig, ax = plt.subplots()
ax.plot(times, single_component)
ax.set_xlabel("time $t$ in years")
ax.set_ylabel("signal amplitude $x(t)$")
ax.set_title("Single-component signal")
fig.tight_layout()
plt.savefig("single_component.png")
plt.savefig("single_component.pdf")
plt.close(fig)

# Question 1: what is the maximum time step dt that can be used to sample
# the synthetic time series correctly? Derive a general formula for the
# maximum time step admissible for a monochromatic time series of period
# t_0. What effect do you expect to observe if the time step is too large?
# (Written answer only: write it as a comment below.)

#### Write your answer here ####


#### End of your answer ####

# -----------------------------------------------------------------------
# 2.2. Synthetic multi-component signal
# -----------------------------------------------------------------------

# Question 2: build s(t) spanning 1850-2010, one point per month, with
# four harmonic components of periods 0.5, 1, 11, and 60 years.
# Do not forget to plot the corresponding timeseries.  
#### Write your code here ####


#### End of your code ####

# -----------------------------------------------------------------------
# 2.3. Spectral analysis
# -----------------------------------------------------------------------

# Compute the Fourier transform of the monochromatic signal x(t)
n_fft = len(times)
spectrum = np.fft.rfft(single_component, n=n_fft)
spectral_amplitude = np.abs(spectrum)

# Calculate periods
frequencies = np.fft.rfftfreq(n_fft, d=dt)
frequencies[0] = np.nan
periods = 1 / frequencies  # Avoid division by zero

# Prepare the plot
fig, ax = plt.subplots(ncols=2, figsize=(8, 3))

# Plot the signal
ax[0].plot(times, single_component)
ax[0].set_xlabel("time $t$ in years")
ax[0].set_ylabel("signal amplitude $x(t)$")
ax[0].set_title("Single-component signal")
ax[0].grid()

# Plot the spectrum
ax[1].axvline(single_component_period, color="C1", label="True period")
ax[1].semilogx(periods, np.abs(spectrum))
ax[1].set_xlabel("Period $T$ in years")
ax[1].set_ylabel(r"Spectral amplitude $|\hat{x}(f)|$")
ax[1].set_title("Single-component signal spectrum")
ax[1].grid()
ax[1].legend()

fig.tight_layout()
plt.savefig("single_component_spectrum.png")
plt.savefig("single_component_spectrum.pdf")
plt.close(fig)

# Question 3: adapt the code above to the multi-component signal s(t)
# built in Question 2. Plot its spectrum. What do you observe? 

#### Write your code here ####


#### End of your code ####

# -----------------------------------------------------------------------
# 2.4. Filtering
# -----------------------------------------------------------------------

# Example: bandpass filter with corner periods 5 and 15 years, applied
# to the monochromatic signal x(t).

period_min, period_max = 5, 15

# Get the Nyquist frequency for expressing the filter in normalized units
nyquist = 1 / (2 * dt)
frequency_low = 1 / period_max / nyquist
frequency_high = 1 / period_min / nyquist

# Filter the signal
filter_order = 1
b, a = signal.butter(filter_order, [frequency_low, frequency_high], btype="bandpass")
filtered = signal.filtfilt(b, a, single_component)

# Get spectrum
spectral_amplitude = np.abs(np.fft.rfft(single_component))
spectral_amplitude_filtered = np.abs(np.fft.rfft(filtered))
frequencies = np.fft.rfftfreq(len(single_component), dt)
frequencies[0] = np.nan
periods = 1 / frequencies

# Get filter spectrum
filter_frequencies, filter_spectrum = signal.freqz(b, a, fs=2 * nyquist)
filter_frequencies[0] = np.nan
filter_periods = 1 / filter_frequencies
filter_transmission = np.abs(filter_spectrum)

# Prepare the plot
fig, ax = plt.subplots(ncols=2, figsize=(8, 3))

# Plot the time series
ax[0].plot(times, single_component, label="$x(t)$")
ax[0].plot(times, filtered, label="$y(t)$")
ax[0].set_xlabel("time $t$ in years")
ax[0].set_ylabel("signal amplitude")
ax[0].set_title("Time domain")
ax[0].legend(loc="center right")
ax[0].grid()

# Plot the spectrum
ax[1].semilogx(periods, spectral_amplitude, label=r"$|\hat{x}(f)|$")
ax[1].semilogx(periods, spectral_amplitude_filtered, label=r"$|\hat{y}(f)|$")
ax[1].set_xlabel("period $T$ in years")
ax[1].set_ylabel("spectral amplitude")
ax[1].set_title("Spectral domain")
ax[1].legend(loc="center right")
ax[1].grid()

# Twin axes for the filter
ax_filter = ax[1].twinx()
ax_filter.semilogx(filter_periods, filter_transmission, "C2")
ax_filter.set_ylabel(r"Filter amplitude $|\hat{h}(f)|$", color="C2")
ax_filter.axvline(period_min, color="C2", linestyle="--")
ax_filter.axvline(period_max, color="C2", linestyle="--")

fig.tight_layout()
plt.savefig("./bandpass_example.png")
plt.savefig("./bandpass_example.pdf")
plt.close(fig)

# Question 4: extract the 11-year component of s(t). Plot the filtered
# signal against the original one, and compare their spectra. Then
# improve the reconstruction (e.g. by padding the timeseries) and
# comment on the difference.

#### Write your code here ####


#### End of your code ####
