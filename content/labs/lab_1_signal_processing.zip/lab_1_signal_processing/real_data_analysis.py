"""Basic signal processing with Python -- real geomagnetic data.

Run with:
    python real_data_analysis.py

"""

import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
from scipy import signal

# -----------------------------------------------------------------------
# 3.1. Loading the data
# -----------------------------------------------------------------------

# Path to the data
filename = "data/chambon_la_foret.dat"

# Load the data
data = pd.read_fwf(filename, skiprows=9, strip=True)

# Turn years into datetime objects
# First, concatenate the year and month columns
date_time_concatenated = data.date.astype(str) + " " + data.time.astype(str)

# Then, convert to datetime objects
data["datetime"] = pd.to_datetime(date_time_concatenated)

# Drop the columns that are not needed anymore
data.drop(["date", "time", "doy"], axis=1, inplace=True)

# Set the datetime column as index
data.set_index("datetime", inplace=True)

# Sampling interval: one value per month (in years)
dt = 1 / 12

# Plot the vertical component of the magnetic field
ax = data.clfz.plot(grid=True, ylabel="$Z(t)$ in nT at Chambon-la-Foret")
ax.set_xlabel("Time $t$ in years")
fig = ax.get_figure()
fig.tight_layout()
plt.savefig("clfz_raw.png")
plt.savefig("clfz_raw.pdf")
plt.close(fig)

# Detrend Z(t) with scipy.signal.detrend and plot the detrended signal.

#### Write your code here ####


#### End of your code ####

# -----------------------------------------------------------------------
# 3.2. Spectral analysis
# -----------------------------------------------------------------------

# Question 5: compute and plot X(t), the Northward component, from
# X = H * cos(D) (see the header of data/chambon_la_foret.dat; D is in
# minutes of arc and must be converted to degrees, then radians).
# Compute X_hat(f) and plot the power spectral density |X_hat|^2(f),
# ideally alongside X(t) on the same figure. Discuss the peaks you see.

#### Write your code here ####


#### End of your code ####

# -----------------------------------------------------------------------
# 3.3. Filtering
# -----------------------------------------------------------------------

# Question 5 (continued): filter out the long-period component of X(t),
# keeping periods shorter than about 20 years. Plot the original
# (possibly detrended) X(t) and its filtered version X_tilde(t) on one
# graph, and the spectra |X_hat|^2(f) and |X_tilde_hat|^2(f) on a
# second graph (both graphs on the same figure).

#### Write your code here ####


#### End of your code ####

# -----------------------------------------------------------------------
# 3.4. Correlating with the sunspot number
# -----------------------------------------------------------------------

# Convert the datetime index to decimal years
dyear_clf = data.index.year + (data.index.dayofyear - 1) / 365

# Parse date from decimal year
sun_spots = pd.read_fwf("data/sunspot_number.dat")
sun_spots.columns = ["decimal_year", "sun_spot_number"]

# Select data within period range of interest
sun_spots = sun_spots[
    (sun_spots.decimal_year >= dyear_clf.min())
    & (sun_spots.decimal_year <= dyear_clf.max())
]

fig, ax = plt.subplots(figsize=(10, 5))
ax.plot(sun_spots["decimal_year"], sun_spots["sun_spot_number"], label="SSN")
ax.legend(loc="best")

ax2 = ax.twinx()

# Question 6: plot the filtered X_tilde(t) on top, using the secondary
# y-axis ax2. What do you observe? Propose an explanation.

#### Write your code here ####


#### End of your code ####

# Label
ax.set_xlabel("Time $t$ in years")
ax.set_ylabel("Sun spot number $S(t)$")
ax.grid()

fig.tight_layout()
plt.savefig("sunspot_correlation.png")
plt.savefig("sunspot_correlation.pdf")
plt.close(fig)
